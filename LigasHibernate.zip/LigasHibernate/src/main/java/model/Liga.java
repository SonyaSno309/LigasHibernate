package model;

import javax.persistence.*;
import java.util.List;
import java.util.Date;

@Entity
@Table(name = "Ligas")
public class Liga {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "nombre_liga", nullable = false)
    private String nombreLiga;

    @Column(name = "fecha_inicio")
    private Date fechaInicio;

    @Column(name = "fecha_fin")
    private Date fechaFin;

    @OneToMany(mappedBy = "liga", cascade = CascadeType.ALL)
    private List<Equipo> equipos;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombreLiga() { return nombreLiga; }
    public void setNombreLiga(String nombreLiga) { this.nombreLiga = nombreLiga; }

    public Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public Date getFechaFin() { return fechaFin; }
    public void setFechaFin(Date fechaFin) { this.fechaFin = fechaFin; }
}
