package dao;

import model.Entrenador;
import model.Equipo;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class EntrenadorDAO {

    public static void crearEntrenador(String nombre, double calificacion, int titulos, int idEquipo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Equipo equipo = session.get(Equipo.class, idEquipo);
        if (equipo != null) {
            if (equipo.getEntrenador() != null) {
                System.out.println("El equipo " + equipo.getNombreEquipo() + " ya tiene un entrenador asignado.");
            } else {
                Entrenador entrenador = new Entrenador();
                entrenador.setNombre(nombre);
                entrenador.setCalificacion(calificacion);
                entrenador.setTitulos(titulos);
                entrenador.setEquipo(equipo);

                session.save(entrenador);
                transaction.commit();
                System.out.println("Entrenador creado correctamente: " + nombre);
            }
        } else {
            System.out.println("No se encontró el equipo con ID: " + idEquipo);
        }

        session.close();
    }

    public static List<Entrenador> obtenerEntrenadores() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Entrenador> entrenadores = session.createQuery("FROM Entrenador", Entrenador.class).list();
        session.close();
        return entrenadores;
    }
    public static List<Entrenador> obtenerEntrenadoresPorLiga(int idLiga) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Entrenador> entrenadores = session.createQuery(
                        "SELECT e FROM Entrenador e WHERE e.equipo.liga.id = :idLiga", Entrenador.class)
                .setParameter("idLiga", idLiga)
                .list();
        session.close();
        return entrenadores;
    }

    public static void editarEntrenador(int id, String nuevoNombre, double nuevaCalificacion) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Entrenador entrenador = session.get(Entrenador.class, id);
        if (entrenador != null) {
            entrenador.setNombre(nuevoNombre);
            entrenador.setCalificacion(nuevaCalificacion);
            session.update(entrenador);
            transaction.commit();
            System.out.println("Entrenador actualizado correctamente: " + nuevoNombre);
        } else {
            System.out.println("No se encontró el entrenador con ID: " + id);
        }

        session.close();
    }

    public static void eliminarEntrenador(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Entrenador entrenador = session.get(Entrenador.class, id);
        if (entrenador != null) {
            session.delete(entrenador);
            transaction.commit();
            System.out.println("Entrenador eliminado correctamente.");
        } else {
            System.out.println("No se encontró el entrenador con ID: " + id);
        }

        session.close();
    }
}
