package dao;

import model.Equipo;
import model.Liga;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class EquipoDAO {


    public static void crearEquipo(String nombre, String ciudad, int idLiga) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Liga liga = session.get(Liga.class, idLiga);
        if (liga != null) {
            Equipo equipo = new Equipo();
            equipo.setNombreEquipo(nombre);
            equipo.setCiudad(ciudad);
            equipo.setLiga(liga);

            session.save(equipo);
            transaction.commit();
            System.out.println("Equipo creado correctamente: " + nombre);
        } else {
            System.out.println("No se encontró la liga con ID: " + idLiga);
        }

        session.close();
    }


    public static List<Equipo> obtenerEquipos() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Equipo> equipos = session.createQuery("FROM Equipo", Equipo.class).list();
        session.close();
        return equipos;
    }
    public static List<Equipo> obtenerEquiposPorLiga(int idLiga) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Equipo> equipos = session.createQuery("FROM Equipo WHERE liga.id = :idLiga", Equipo.class)
                .setParameter("idLiga", idLiga)
                .list();
        session.close();
        return equipos;
    }


    public static void editarEquipo(int id, String nuevoNombre, String nuevaCiudad) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Equipo equipo = session.get(Equipo.class, id);
        if (equipo != null) {
            equipo.setNombreEquipo(nuevoNombre);
            equipo.setCiudad(nuevaCiudad);
            session.update(equipo);
            transaction.commit();
            System.out.println("Equipo actualizado correctamente: " + nuevoNombre);
        } else {
            System.out.println("No se encontró el equipo con ID: " + id);
        }

        session.close();
    }

    public static void eliminarEquipo(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Equipo equipo = session.get(Equipo.class, id);
        if (equipo != null) {
            session.delete(equipo);
            transaction.commit();
            System.out.println("Equipo eliminado correctamente.");
        } else {
            System.out.println("No se encontró el equipo con ID: " + id);
        }

        session.close();
    }
}
