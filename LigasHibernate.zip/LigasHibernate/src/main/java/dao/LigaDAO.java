package dao;

import model.Liga;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class LigaDAO {

    public static void crearLiga(String nombre, java.util.Date fechaInicio, java.util.Date fechaFin) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Liga liga = new Liga();
        liga.setNombreLiga(nombre);
        liga.setFechaInicio(fechaInicio);
        liga.setFechaFin(fechaFin);

        session.save(liga);
        transaction.commit();
        session.close();

        System.out.println("Liga creada correctamente: " + nombre);
    }

    public static void editarLiga(int id, String nuevoNombre) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Liga liga = session.get(Liga.class, id);
        if (liga != null) {
            liga.setNombreLiga(nuevoNombre);
            session.update(liga);
            transaction.commit();
            System.out.println("Liga actualizada correctamente: " + nuevoNombre);
        } else {
            System.out.println("No se encontró la liga con ID: " + id);
        }

        session.close();
    }

    public static void eliminarLiga(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Liga liga = session.get(Liga.class, id);
        if (liga != null) {
            session.delete(liga);
            transaction.commit();
            System.out.println("Liga eliminada correctamente.");
        } else {
            System.out.println("No se encontró la liga con ID: " + id);
        }

        session.close();
    }

    public static List<Liga> obtenerLigas() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Liga> ligas = session.createQuery("FROM Liga", Liga.class).list();
        session.close();
        return ligas;
    }
}
