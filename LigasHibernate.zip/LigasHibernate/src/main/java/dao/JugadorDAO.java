package dao;

import model.Equipo;
import model.Jugador;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class JugadorDAO {

    public static void crearJugador(String nombre, String posicion, double valorMercado, int goles, String nacionalidad, int idEquipo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Equipo equipo = session.get(Equipo.class, idEquipo);
        if (equipo != null) {
            Jugador jugador = new Jugador();
            jugador.setNombre(nombre);
            jugador.setPosicion(posicion);
            jugador.setValorMercado(valorMercado);
            jugador.setGoles(goles);
            jugador.setNacionalidad(nacionalidad);
            jugador.setEquipo(equipo);

            session.save(jugador);
            transaction.commit();
            System.out.println("Jugador creado correctamente: " + nombre);
        } else {
            System.out.println("No se encontró el equipo con ID: " + idEquipo);
        }

        session.close();
    }

    public static List<Jugador> obtenerJugadores() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Jugador> jugadores = session.createQuery("FROM Jugador", Jugador.class).list();
        session.close();
        return jugadores;
    }
    public static List<Jugador> obtenerJugadoresPorEquipo(int idEquipo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Jugador> jugadores = session.createQuery("FROM Jugador WHERE equipo.id = :idEquipo", Jugador.class)
                .setParameter("idEquipo", idEquipo)
                .list();
        session.close();
        return jugadores;
    }

    public static void editarJugador(int id, String nuevoNombre, double nuevoValor) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Jugador jugador = session.get(Jugador.class, id);
        if (jugador != null) {
            jugador.setNombre(nuevoNombre);
            jugador.setValorMercado(nuevoValor);
            session.update(jugador);
            transaction.commit();
            System.out.println("Jugador actualizado correctamente: " + nuevoNombre);
        } else {
            System.out.println("No se encontró el jugador con ID: " + id);
        }

        session.close();
    }

    public static void eliminarJugador(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Jugador jugador = session.get(Jugador.class, id);
        if (jugador != null) {
            session.delete(jugador);
            transaction.commit();
            System.out.println("Jugador eliminado correctamente.");
        } else {
            System.out.println("No se encontró el jugador con ID: " + id);
        }

        session.close();
    }
}
