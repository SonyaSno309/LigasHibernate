package org.example;

import dao.EquipoDAO;
import dao.EntrenadorDAO;
import dao.JugadorDAO;
import dao.LigaDAO;
import model.Equipo;
import model.Entrenador;
import model.Jugador;
import model.Liga;

import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        LigaDAO.crearLiga("Champions League", new Date(), new Date());
        List<Liga> ligas = LigaDAO.obtenerLigas();
        if (ligas.isEmpty()) {
            System.out.println("No hay ligas disponibles.");
            return;
        }
        int idLiga = ligas.get(0).getId();

        EquipoDAO.crearEquipo("Real Madrid", "Madrid", idLiga);
        EquipoDAO.crearEquipo("Manchester City", "Manchester", idLiga);
        EquipoDAO.crearEquipo("Bayern Munich", "Múnich", idLiga);

        List<Equipo> equipos = EquipoDAO.obtenerEquipos();
        if (equipos.size() < 3) {
            System.out.println("No se crearon suficientes equipos.");
            return;
        }

        int idEquipo1 = equipos.get(0).getId();
        int idEquipo2 = equipos.get(1).getId();
        int idEquipo3 = equipos.get(2).getId();

        JugadorDAO.crearJugador("Karim Benzema", "Delantero", 40.0, 30, "Francés", idEquipo1);
        JugadorDAO.crearJugador("Vinícius Jr.", "Extremo", 50.0, 20, "Brasileño", idEquipo1);
        JugadorDAO.crearJugador("Erling Haaland", "Delantero", 60.0, 40, "Noruego", idEquipo2);
        JugadorDAO.crearJugador("Kevin De Bruyne", "Mediocampista", 45.0, 10, "Belga", idEquipo2);
        JugadorDAO.crearJugador("Thomas Müller", "Mediocampista", 30.0, 15, "Alemán", idEquipo3);
        JugadorDAO.crearJugador("Manuel Neuer", "Portero", 25.0, 0, "Alemán", idEquipo3);

        List<Jugador> jugadores = JugadorDAO.obtenerJugadores();
        if (jugadores.size() >= 2) {
            JugadorDAO.editarJugador(jugadores.get(0).getId(), "Karim Benzema (Fichado)", 42.0);
            JugadorDAO.editarJugador(jugadores.get(1).getId(), "Vinícius Jr. (Fichado)", 52.0);
        }

        EntrenadorDAO.crearEntrenador("Carlo Ancelotti", 9.8, 20, idEquipo1);
        EntrenadorDAO.crearEntrenador("Pep Guardiola", 9.9, 25, idEquipo2);
        EntrenadorDAO.crearEntrenador("Thomas Tuchel", 8.5, 10, idEquipo3);

        System.out.println("\n Equipos registrados:");
        for (Equipo equipo : EquipoDAO.obtenerEquipos()) {
            System.out.println("- " + equipo.getNombreEquipo() + " (" + equipo.getCiudad() + ")");
        }

        System.out.println("\n Jugadores del equipo: " + equipos.get(0).getNombreEquipo());
        for (Jugador jugador : JugadorDAO.obtenerJugadoresPorEquipo(idEquipo1)) {
            System.out.println("- " + jugador.getNombre() + " (" + jugador.getPosicion() + ") - Valor: " + jugador.getValorMercado() + "M€");
        }

        System.out.println("\n Equipos en la liga: " + ligas.get(0).getNombreLiga());
        for (Equipo equipo : EquipoDAO.obtenerEquiposPorLiga(idLiga)) {
            System.out.println("- " + equipo.getNombreEquipo());
        }

        System.out.println("\n Entrenadores en la liga: " + ligas.get(0).getNombreLiga());
        for (Entrenador entrenador : EntrenadorDAO.obtenerEntrenadoresPorLiga(idLiga)) {
            System.out.println("- " + entrenador.getNombre() + " (Calificación: " + entrenador.getCalificacion() + ")");
        }
    }
}
